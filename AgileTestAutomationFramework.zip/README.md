# AgileTestAutomationFramework

This is a modular BDD Test Automation Framework built with Java, TestNG, Cucumber, Gherkin, JSON, and XML. It is structured for CI/CD readiness and aligns with Agile testing best practices.

## Structure
- **Step Definitions:** Java step implementations under `steps/`
- **Feature Files:** Gherkin scenarios in `features/`
- **Test Data:** JSON-driven input in `data/`
- **Configuration:** `testng.xml` in `config/`
- **Runner:** TestNG-based runner for executing Cucumber tests

## Usage
1. Import into IntelliJ IDEA as a Maven project.
2. Add required dependencies (e.g., Selenium, Cucumber, TestNG).
3. Run `TestRunner.java` or through `testng.xml`.
